/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex6;

/**
 *
 * @author diego
 */
public abstract class  Componente {
    private String Texto;

    /**
     * @return the Texto
     */
    public String getTexto() {
        return Texto;
    }

    /**
     * @param Texto the Texto to set
     */
    public void setTexto(String Texto) {
        this.Texto = Texto;
    }
    
}
