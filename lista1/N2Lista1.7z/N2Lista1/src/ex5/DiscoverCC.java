/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author diego
 */
public class DiscoverCC extends CreditCard{
    
    public DiscoverCC(String numero, String dataExpiracao, String titular) {
        super(numero, dataExpiracao, titular);
    }
    
}
